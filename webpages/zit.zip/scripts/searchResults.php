<?php
//Anthony Levine
	session_start();
	include('../inc/creds.php');
	$function = $_POST['function'];
	//$function = "getDate";
	//$function = "getloc";
	$typeone = "rurfarm";
	$typetwo = "urbpop";
	$location = 1;
	
	
	if($function == 1)
	{
		//$typeone = $_POST['typeone'];
		//$typetwo = $_POST['typetwo'];
		
		$queryOne = "SELECT location FROM ".$typeone." ORDER BY location ASC";
		$resultOne = mysql_query($queryOne) or die("falsee");
		$queryTwo = "SELECT location FROM ".$typetwo;
		$resultTwo = mysql_query($queryTwo) or die("feealse");
		
		
		$counter = 0;
		$locationOneArray;
		$counterTwo = 0;
		$locationTwoArray;
		while($locOne = mysql_fetch_array($resultOne))
		{
			$locationOneArray[$counter] = $locOne['location'];
			$counter++;
		}
		while($locTwo = mysql_fetch_array($resultTwo))
		{
				$locationTwoArray[$counterTwo] = $locTwo['location'];
				$counterTwo++;
		}
		$results = array_intersect($locationOneArray, $locationTwoArray);
		
		$returnString = "";
		for($i = 0; $i < 50; $i++)
		{
			$query = "SELECT * FROM locations WHERE _ID = ".$results[$i];
			$locResult = mysql_query($query);
			$locArray = mysql_fetch_array($locResult);
			if($i != 49) $returnString = $returnString.$locArray['county']." - ".$locArray['_ID'].", ";
			else $returnString = $returnString.$locArray['county']." - ".$locArray['_ID'];
		
		}
		echo $returnString;	
	}
	else if($function == 2)
	{
		$queryLocOne = "SELECT start_date, end_date FROM ".$typeone." WHERE location = ".$location;
		$queryLocTwo = "SELECT start_date, end_date FROM ".$typetwo." WHERE location = ".$location;
		
		$dateResultOne = mysql_query($queryLocOne);
		$dateResultTwo = mysql_query($queryLocTwo);
		$dateCountOne = 0;
		while($dateOne = mysql_fetch_array($dateResultOne))
		{
			$dateArrayOne[$dateCountOne] = $dateOne['start_date']." - ".$dateOne['end_date'];
			$dateCountOne++;
		}
		$dateArrayOne = array_unique($dateArrayOne);
		$dateCountTwo = 0;
		while($dateTwo = mysql_fetch_array($dateResultTwo))
		{
			$dateArrayTwo[$dateCountTwo] = $dateTwo['start_date']." - ".$dateTwo['end_date'];
			$dateCountTwo++;
		}
		$dateArrayTwo = array_unique($dateArrayTwo);
		$results = array_intersect($dateArrayOne, $dateArrayTwo);
		if($results == null) echo "false";
		else
		{
			$dateResult = "";
			$arraycount = count($results);
			for($i = 0; $i < $arraycount; $i++)
			{
				if($i == $arraycount-1) $dateResult = $dateResult.$results[$i];
				else $dateResult = $dateResult.$result[$i].", ";
			}
			echo $dateResult;
		}
	}
?>