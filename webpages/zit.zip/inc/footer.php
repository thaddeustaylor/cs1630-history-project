	<footer class="well">
		<p align="center">&copy; University of Pittsburgh, Computer Science 1630 - History Team</p>
		<p align="center"><a href="http://www.pitt.edu">www.pitt.edu</a> | <a href="about.php">About</a> | <a href="contact.php">Contact Us</a></p>
		
	</footer>