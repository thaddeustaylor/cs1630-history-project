<?php

/*$dbserver = "localhost:3306";
$dbusername = "root";
$dbpassword = "root";
$dbname = "user_information";*/

$dbserver = "mysql.cs.pitt.edu";
$dbname = "cs1630history";
$username = "tbl8";
$password = "datasucks()";

$userlogintable = "user_login";

if(isSet($needMYSQLI) && $needMYSQLI == true)
{
	$mysqli = mysqli_connect($dbserver, $dbusername, $dbpassword, $dbname);
	if(!$mysqli) echo "no connect";
}
else
{
	mysql_connect($dbserver, $dbusername, $dbpassword);
	mysql_select_db($dbname);
}
?>