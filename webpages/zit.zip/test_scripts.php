<?php

/*$dbserver = "localhost:3306";
$dbusername = "root";
$dbpassword = "root";
$dbname = "user_information";

	
$connect = mysql_connect($dbserver, $dbusername, $dbpassword);
mysql_select_db($dbname); 

/*
$password = crypt('anthony');
$query = "INSERT INTO user_login VALUES ('acl37@pitt.edu', '".$password."', 1)";
mysql_query($query);

$password = crypt('cj');
$query = "INSERT INTO user_login VALUES ('cjf40@pitt.edu', '".$password."', 1)";
mysql_query($query);

$password = crypt('evan');
$query = "INSERT INTO user_login VALUES ('emm82@pitt.edu', '".$password."', 1)";
mysql_query($query);

$password = crypt('jake');
$query = "INSERT INTO user_login VALUES ('jdl56@pitt.edu', '".$password."', 1)";
mysql_query($query);

$password = crypt('matthew');
$query = "INSERT INTO user_login VALUES ('mwg7@pitt.edu', '".$password."', 1)";
mysql_query($query);

$password = crypt('rob');
$query = "INSERT INTO user_login VALUES ('rbf8@pitt.edu', '".$password."', 1)";
mysql_query($query);

$password = crypt('ryan');
$query = "INSERT INTO user_login VALUES ('rpb25@pitt.edu', '".$password."', 1)";
mysql_query($query);

$password = crypt('tyler');
$query = "INSERT INTO user_login VALUES ('tah47@pitt.edu', '".$password."', 1)";
mysql_query($query);

*/

/*$file=fopen("census.txt","r");
while(!feof($file))
  {
  $line = fgets($file);
  $pos = strrpos($line, ",");
  $abbr = substr($line, 0, $pos);
  $name = substr($line, $pos+1);
  $name = trim($name);
  $query = "INSERT INTO testTypeToAbbr VALUES ('".$abbr."', '".$name."')";
  mysql_query($query);
  
  
  }*/

  
?>
